import { ScheduleBuilder } from "@/components/schedule-builder"

export default function ScheduleBuilderPage() {
  return <ScheduleBuilder />
}
