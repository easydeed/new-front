// Wizard localStorage keys for draft persistence
export const WIZARD_DRAFT_KEY_MODERN = "deedpro_wizard_draft_modern"
export const WIZARD_DRAFT_KEY_CLASSIC = "deedpro_wizard_draft_classic"
